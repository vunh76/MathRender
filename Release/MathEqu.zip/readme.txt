Copy MathEqu.Ocx to System folder.
Start -> Run -> Regsvr32 MathEqu.Ocx
Run lmathfont to install font.
Run TestOcx to see an example about component.
Read Math Notation for mathematical syntax.
Note: Need VB6 runtime (MSVBVM60.DLL)
Open an existing project or create new project in VB6 IDE.
Choose Project -> Components -> Check MathEqu
Drag MathEqu icon from toolbox to form. MathEqu interface is very easy to understand.
This version is under progress so that it lack few mathematical symbols and may have error. Re-visit web site to get newer version